export const data = [{
    id:1,
    name: "Akshay",
    image: "https://media.threatpost.com/wp-content/uploads/sites/103/2019/09/26105755/fish-1.jpg"
},
{
    id:2,
    name: "Akshay",
    image: "https://media.threatpost.com/wp-content/uploads/sites/103/2019/09/26105755/fish-1.jpg"
},
{
    id:3,
    name: "Akshay",
    image: "https://media.threatpost.com/wp-content/uploads/sites/103/2019/09/26105755/fish-1.jpg"
},
{
    id:4,
    name: "Akshay",
    image: "https://media.threatpost.com/wp-content/uploads/sites/103/2019/09/26105755/fish-1.jpg"
},
{
    id:5,
    name: "Akshay",
    image: "https://media.threatpost.com/wp-content/uploads/sites/103/2019/09/26105755/fish-1.jpg"
}]