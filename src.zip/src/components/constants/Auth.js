export const Auth = {
    userName: "Akshay",
    password: "123456"
}