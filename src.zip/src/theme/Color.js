export const color = {
    white:"#FFF",
    black:"#000",
    primaryColor:"blue",
    secondoryColor:"grey"
}